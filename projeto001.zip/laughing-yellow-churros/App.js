import React, {Component} from 'react';
import {View,Text, Image} from 'react-native';

class App extends Component{
  render(){
    return(
      <View style={{backgroundColor:'black', height: '100%'}}>
      <Text>{'\n\n\n'}Olá Mundo!!!</Text>
      <Text>{'\n'}Meu Primeiro App!</Text>
      <Text style={{color:'white',fontSize: 50, margin:30, fontFamily: 'cursive', textAlign: 'center'}}>Vasco da Gama</Text>
      <Image
      source={{uri: 'https://acdn-us.mitiendanube.com/stores/002/418/650/products/img_3212-0d77d89e804244be6d17206264950998-1024-1024.png'}}
      style={{width: 300, height: 350, margin: 50}}/>
      <Text style={{color: 'white', fontSize: 20}}>{'\n\n'}📍Vasco da Gama</Text>
      </View>
    );
  }
}
export default App;